package de.mercedes;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import javax.xml.XMLConstants;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

/**
 * Parser für eine XML-Datei mit Movie-Daten.
 *
 * @author Miroslav Vladov
 */
public class MovieParser {

    /**
     * Inhalt der XML-Datei.
     */
    private String xmlFileContent;

    /**
     * Konstruktor.
     *
     * @param xmlFileContent Inhalt der XML-Datei
     */
    public MovieParser(String xmlFileContent) {
        this.xmlFileContent = xmlFileContent;
    }

    /**
     * Liefert die Serie der XML-Datei.
     *
     * @return Serie der XML-Datei
     * @throws ParserConfigurationException
     * @throws SAXException
     * @throws IOException
     */
    public Series getSeries() throws ParserConfigurationException, SAXException, IOException {
        DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
        dbf.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, true);
        DocumentBuilder db = dbf.newDocumentBuilder();
        // Temporäre XML-Datei erstellen
        File xmlFile = new File("");
        Document doc = db.parse(xmlFile);
        doc.getDocumentElement().normalize();
        NodeList list = doc.getElementsByTagName("Series");
        Series series = new Series();
        for (int count = 0; count < list.getLength(); count++) {
            Node node = list.item(count);
            if (node.getNodeType() == Node.ELEMENT_NODE) {
                Element element = (Element) node;
                String id = element.getAttribute("id");
                series.setId(Integer.valueOf(id));

                String actors = element.getAttribute("Actors");
                series.setActors(actors);

                String genre = element.getAttribute("Genre");
                series.setGenre(genre);

                String language = element.getAttribute("Language");
                series.setLanguage(language);
            }
        }

        return series;
    }

    /**
     * Liefert eine Liste mit den Episoden der XML-Datei.
     *
     * @return Liste mit den Episoden der XML-Datei
     */
    public List<Episode> getEpisodes() {
        List<Episode> episodes = new ArrayList<>();
        Episode firstEpisode = new Episode(1);
        firstEpisode.setName("First episode");
        firstEpisode.setLanguage("German");
        firstEpisode.setDirector("The director");
        
        Episode secEpisode = new Episode();
        secEpisode.setName("Second episode");
        secEpisode.setLanguage("Englisch");
        secEpisode.setDirector("The new director");
        
        episodes.addAll(List.of(firstEpisode, secEpisode));
        return episodes;
    }

}
