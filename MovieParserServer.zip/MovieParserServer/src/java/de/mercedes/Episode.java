package de.mercedes;

/**
 * Klasse für eine Episode.
 *
 * @author Miroslav Vladov
 */
public class Episode {

    /**
     * ID der Episode.
     */
    private int id;

    /**
     * Kombinierte Nummer der Episode.
     */
    private int combinedNumber;

    /**
     * Kombinierte Spielzeit der Episode.
     */
    private int combinedSeason;

    /**
     * Regisseur der Episode.
     */
    private String director;

    /**
     * Name der Episode.
     */
    private String name;

    /**
     * Nummer der Episode.
     */
    private int number;

    /**
     * Sprache der Episode.
     */
    private String language;

    /**
     * Default-Konstruktor.
     */
    public Episode() {
    }

    /**
     * Konstruktor.
     *
     * @param id ID der Episode
     */
    public Episode(int id) {
        this.id = id;
    }

    /**
     * Liefert die ID der Episode zurück.
     *
     * @return ID der Episode
     */
    public int getId() {
        return id;
    }

    /**
     * Liefert die kombinierte Nummer der Episode zurück.
     *
     * @return Kombinierte Nummer der Episode
     */
    public int getCombinedNumber() {
        return combinedNumber;
    }

    /**
     * Setzt die angegebene kombinierte Nummer der Episode.
     *
     * @param combinedNumber Kombinierte Nummer der Episode
     */
    public void setCombinedNumber(int combinedNumber) {
        this.combinedNumber = combinedNumber;
    }

    /**
     * Liefert die kombinierte Spielzeit der Episode.
     *
     * @return Kombinierte Spielzeit der Episode
     */
    public int getCombinedSeason() {
        return combinedSeason;
    }

    /**
     * Setzt die angegebene kombinierte Spielzeit der Episode.
     *
     * @param combinedSeason Kombinierte Spielzeit der Episode
     */
    public void setCombinedSeason(int combinedSeason) {
        this.combinedSeason = combinedSeason;
    }

    /**
     * Liefert den Regisseur der Episode.
     *
     * @return Regisseur der Episode
     */
    public String getDirector() {
        return director;
    }

    /**
     * Setzt den angegebenen Regisseur der Episode.
     *
     * @param director Regisseur der Episode
     */
    public void setDirector(String director) {
        this.director = director;
    }

    /**
     * Liefert die Bezeichnung der Episode.
     *
     * @return Bezeichnung der Episode
     */
    public String getName() {
        return name;
    }

    /**
     * Setzt die angegebene Bezeichnung der Episode.
     *
     * @param name Bezeichnung der Episode
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * Liefert die Nummer der Episode zurück.
     *
     * @return Nummer der Episode
     */
    public int getNumber() {
        return number;
    }

    /**
     * Setzt die Nummer der Episode.
     *
     * @param number Nummer der Episode
     */
    public void setNumber(int number) {
        this.number = number;
    }

    /**
     * Liefert die Sprache der Episode zurück.
     *
     * @return Sprache der Episode
     */
    public String getLanguage() {
        return language;
    }

    /**
     * Setzt die angegebene Sprache der Episode.
     *
     * @param language Sprache der Episode
     */
    public void setLanguage(String language) {
        this.language = language;
    }

}
