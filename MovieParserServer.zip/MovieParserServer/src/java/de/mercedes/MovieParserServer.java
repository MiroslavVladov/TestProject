package de.mercedes;

import java.io.*;
import java.util.List;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Überschrift: MovieParserServer.
 *
 * @author Miroslav Vladov
 */
public class MovieParserServer extends HttpServlet {

    @Override
    public void init(ServletConfig config) throws ServletException {
        super.init(config);

        // Logik implementieren falls nötig
    }

    /**
     * Bearbeitet Anfragen der HTTP GET-Methode.
     *
     * @param request Servlet Anfrage
     * @param response Servlet Antwort
     */
    @Override
    public void doGet(HttpServletRequest request, HttpServletResponse response) {
        processRequest(request, response);
    }

    /**
     * Bearbeitet Anfragen der HTTP POST-Methode.
     *
     * @param request Servlet Anfrage
     * @param response Servlet Antwort
     */
    @Override
    public void doPost(HttpServletRequest request, HttpServletResponse response) {
        processRequest(request, response);
    }

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request Servlet Anfrage
     * @param response Servlet Antwort
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response) {
        String cmd = Utils.getParamNotNull(request, "cmd");
        if (cmd.equals("status") || (cmd.length() == 0)) {
            processStatusRequest(response);

        } else if (cmd.equals("getSeries")) {
            String xmlFile = request.getParameter("xmlfile");
            printSeries(response, xmlFile);

        } else if (cmd.equals("getEpisodes")) {
            List<Episode> episodes = new MovieParser(cmd).getEpisodes();
            printEpisodes(response, episodes);
        }
    }

    private void processStatusRequest(HttpServletResponse response) {
        PrintWriter pw = null;
        try {
            response.setContentType("text/plain;charset=UTF-8");
            pw = response.getWriter();
            pw.write("Movie Parser Server is running.");

        } catch (IOException exc) {
            pw.write("Exception while getting the movie Parser Server status: " + exc);
        } finally {
            if (pw != null) {
                pw.close();
            }
        }
    }

    /**
     * Gibt die Serie aus der XML-Datei aus.
     *
     * @param response Servlet Rückmeldung
     * @param xmlFile Inhalt der XML-Datei
     */
    private void printSeries(HttpServletResponse response, String xmlFile) {
        PrintWriter printWriter = null;
        try {
            Series series = new MovieParser(xmlFile).getSeries();
            response.setHeader("Cache-Control", "no-cache"); //HTTP 1.1
            response.setHeader("Pragma", "no-cache"); //HTTP 1.0
            response.setDateHeader("Expires", 0); //prevents caching at the proxy server
            response.setContentType("text/html; charset=UTF-8");

            printWriter = new PrintWriter(new OutputStreamWriter(response.getOutputStream(), "UTF8"), true);
            printWriter.print("<html><head><title>Series</title></head><body>");
            printWriter.print("Series name: " + series.getSeriesName() + "<br>");
            printWriter.print("Genre: " + series.getGenre() + "<br>");
            printWriter.print("Actors: " + series.getActors());
            printWriter.print("</body></html>");
            printWriter.flush();

        } catch (Exception exc) {
            try {
                response.getWriter().print("Error while getting the series of the xml file: " + exc.toString());
            } catch (IOException ex) {
            }
        } finally {
            if (printWriter != null) {
                printWriter.close();
            }
        }
    }

    /**
     * Gibt die einzelnen Episoden aus.
     *
     * @param response Servlet Rückmeldung
     * @param episodes Liste mit Episoden
     */
    private void printEpisodes(HttpServletResponse response, List<Episode> episodes) {
        PrintWriter pw = null;
        try {
            response.setHeader("Cache-Control", "no-cache"); //HTTP 1.1
            response.setHeader("Pragma", "no-cache"); //HTTP 1.0
            response.setDateHeader("Expires", 0); //prevents caching at the proxy server
            response.setContentType("text/html; charset=UTF-8");
            pw = response.getWriter();
            pw.write("<html><head></head><body>");
            for (Episode episode : episodes) {
                pw.print("Episode: " + episode.getName() + "<br>");
                pw.print("Language: " + episode.getLanguage() + "<br>");
                pw.print("Director: " + episode.getDirector() + "<br><br>");
            }

            pw.write("</body></html>");

        } catch (Exception exc) {
            pw.print("Error while getting the episodes of the xml file: " + exc.toString());
        } finally {
            if (pw != null) {
                pw.close();
            }
        }
    }

}
