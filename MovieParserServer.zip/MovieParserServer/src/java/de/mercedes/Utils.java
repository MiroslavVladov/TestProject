package de.mercedes;

import javax.servlet.http.HttpServletRequest;

/**
 * Klasse mit Hilfsfunktionen.
 *
 * @author Miroslav Vladov
 */
public class Utils {

    /**
     * Liefert einen Parameter Wert zurück. Wenn der Parameter nicht existiert,
     * wird keine null sondern ein Leerstring zurückgegeben.
     *
     * @param request HttpRequest Objekt mit allen Parametern
     * @param name Name des gewünschten Parameters
     * @return Wert des Parameters oder Leerstring
     */
    public static String getParamNotNull(HttpServletRequest request, String name) {        
        String value = request.getParameter(name);
        if (value == null) {
            value = "";
        }

        return value;
    }

}
