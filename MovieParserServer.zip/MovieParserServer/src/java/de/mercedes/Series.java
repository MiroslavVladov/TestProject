package de.mercedes;

/**
 * Klasse für eine Serie.
 * 
 * @author Miroslav Vladov
 */
public class Series {

    /**
     * ID der Serie.
     */
    private int id;
    
    /**
     * Liste mit den Schauspielern.
     */
    private String actors;
    
    /**
     * Genre der Serie.
     */
    private String genre;
    
    /**
     * Sprache der Serie.
     */
    private String language;
    
    /**
     * Rating der Serie.
     */
    private int rating;
    
    /**
     * Bezeichnung der Serie.
     */
    private String seriesName;
    
    /**
     * Default-Konstruktor.
     */
    public Series() {        
    }
    
    /**
     * Konstruktor.
     * 
     * @param id ID der Serie
     */
    public Series(int id) {
        this.id = id;
    }
    
    /**
     * Liefert die ID der Serie.
     * 
     * @return ID der Serie
     */
    public int getId() {
        return id;
    }
    
    /**
     * Setzt die angegebene ID der Serie.
     * 
     * @param id ID der Serie
     */
    public void setId(int id) {
        this.id = id;
    }
    
    /**
     * Liefert die Liste mit den Schauspielern.
     * 
     * @return Liste mit Schauspielern
     */
    public String getActors() {
        return actors;
    }
    
    /**
     * Setzt die angegebene Liste mit Schauspielern.
     * 
     * @param actors Liste mit Schauspielern
     */
    public void setActors(String actors) {
        this.actors = actors;
    }
    
    /**
     * Liefert das Genre der Serie zurück.
     * 
     * @return Genre der Serie
     */
    public String getGenre() {
        return genre;
    }
    
    /**
     * Setzt das angegebene Genre der Serie.
     * 
     * @param genre Genre der Serie
     */
    public void setGenre(String genre) {
        this.genre = genre;
    }
    
    /**
     * Liefert die Sprache der Serie.
     * 
     * @return Sprache der Serie
     */
    public String getLanguage() {
        return language;
    }
 
    /**
     * Setzt die angegebene Sprache der Serie.
     * 
     * @param language Sprache der Serie
     */
    public void setLanguage(String language) {
        this.language = language;
    }
    
    /**
     * Liefert das Rating der Serie zurück.
     * 
     * @return Rating der Serie
     */
    public int getRating() {
        return rating;
    }
    
    /**
     * Setzt das angegebene Rating der Serie.
     * 
     * @param rating Rating der Serie
     */
    public void setRating(int rating) {
        this.rating = rating;
    }
    
    /**
     * Liefert die Bezeichnung der Serie zurück.
     * 
     * @return Bezeichnung der Serie
     */
    public String getSeriesName() {
        return seriesName;
    }
    
    /**
     * Setzt die angegebene Bezeichnung der Serie.
     * 
     * @param seriesName Bezeichnung der Serie
     */
    public void setSeriesName(String seriesName) {
        this.seriesName = seriesName;
    }
    
}
