/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package de.mercedes;

import java.io.File;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Priority;
import javafx.scene.layout.RowConstraints;
import javafx.scene.text.Text;
import javafx.scene.web.WebEngine;
import javafx.scene.web.WebView;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;

/**
 * Dialog für die grafischen Komponenten für den Movie Parser Client.
 *
 * @author Miroslav Vladov
 */
public class MovieParserClient extends GridPane implements Runnable {

    /**
     * Hauptdialog
     */
    private Stage stage;

    /**
     * GridPane für die Komponenten auf der oberen Seite.
     */
    private GridPane topGridPane;

    /**
     * Label für die Auswahl einer XML-Datei.
     */
    private Text xmlFileLabel;

    /**
     * Textfeld für die XML-Datei.
     */
    private TextField xmlFileTextField;

    /**
     * Schaltfläche für die Generierung einer HTML-Datei.
     */
    private Button generateHtmlButton;

    /**
     * GridPane für die Komponenten auf der unteren Seite.
     */
    private GridPane bottomGridPane;

    /**
     * Label für die erstellte HTML-Datei.
     */
    private Text htmlFileLabel;

    /**
     * Java FX Browser Ansicht
     */
    private WebView webView;

    /**
     * Java FX Browser Komponente
     */
    private WebEngine webEngine;

    /**
     * Konstruktor.
     *
     * @param stage Hauptdialog
     * @throws Exception
     */
    public MovieParserClient(Stage stage) throws Exception {
        this.stage = stage;
        //setGridLinesVisible(true);
        ColumnConstraints col1 = new ColumnConstraints(10);
        ColumnConstraints col2 = new ColumnConstraints();
        col2.setFillWidth(true);
        col2.setHgrow(Priority.ALWAYS);
        ColumnConstraints col3 = new ColumnConstraints(10);
        getColumnConstraints().addAll(col1, col2, col3);
        RowConstraints row1 = new RowConstraints(10);
        RowConstraints row2 = new RowConstraints();
        RowConstraints row3 = new RowConstraints(15);
        RowConstraints row4 = new RowConstraints();
        RowConstraints row5 = new RowConstraints(10);
        getRowConstraints().addAll(row1, row2, row3, row4, row5);

        // Grafische Komponenten erzeugen        
        createComponents();
        
        Thread thread = new Thread(this);
        thread.start();
    }

    /**
     * Erzeugt die grafischen Komponenten und fügt diese dem Panel hinzu.
     */
    private void createComponents() throws Exception {
        createTopGridPane();
        createXmlFileLabel();
        createXmlFileTextField();
        createGenerHtmlFileButton();
        createBottomGridPane();
        createHtmlFileLabel();
        createHtmlFileWebView();
        add(topGridPane, 1, 1);
        add(bottomGridPane, 1, 3);
    }

    private void createTopGridPane() {
        topGridPane = new GridPane();
        ColumnConstraints col1 = new ColumnConstraints(70);
        ColumnConstraints col2 = new ColumnConstraints(10);
        ColumnConstraints col3 = new ColumnConstraints(300);
        ColumnConstraints col4 = new ColumnConstraints(10);
        ColumnConstraints col5 = new ColumnConstraints(120);
        topGridPane.getColumnConstraints().addAll(col1, col2, col3, col4, col5);

        RowConstraints row1 = new RowConstraints(10);
        RowConstraints row2 = new RowConstraints(15);
        RowConstraints row3 = new RowConstraints(10);
        topGridPane.getRowConstraints().addAll(row1, row2, row3);
    }

    /**
     * Erzeugt das Label für die XML-Datei und fügt es dem Panel hinzu.
     */
    private void createXmlFileLabel() {
        xmlFileLabel = new Text("XML-Datei:");
        topGridPane.add(xmlFileLabel, 0, 2);
    }

    /**
     * Erzeugt das Textfeld für die XML-Datei und fügt es dem Panel hinzu.
     */
    private void createXmlFileTextField() {
        xmlFileTextField = new TextField();
        topGridPane.add(xmlFileTextField, 2, 2);
    }

    /**
     * Erzeugt den Button für die HTML-Generierung und fügt es dem Panel hinzu.
     */
    private void createGenerHtmlFileButton() {
        generateHtmlButton = new Button("Generiere HTML");
        generateHtmlButton.setOnAction(createGenerateHtmlEventHandler());
        topGridPane.add(generateHtmlButton, 4, 2);
    }

    /**
     * Erzeugt den EventHandler für die Generierung der HTML-Datei.
     *
     * @return EventHandler für die Generierung der HTML-Datei
     */
    protected EventHandler<ActionEvent> createGenerateHtmlEventHandler() {
        return new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                // HTTP Request an dem MovieParser-Servlet schicken und anzeigen
                String xmlFile = xmlFileTextField.getText();
                String url = "http://localHost:8080/MovieParser?cmd=get&param1=" + xmlFile + "&param2=getSeries";
                File responseFile = new File("C:/temp/ResponseFile" + System.currentTimeMillis() + ".html");
                //sendHttpRequest(url, responseFile);
                webEngine.loadContent("<html><head></head><body>Testpage from MovieParser server.</body></html>");
            }
        };
    }

    private void createBottomGridPane() {
        bottomGridPane = new GridPane();
        ColumnConstraints col1 = new ColumnConstraints(70);
        ColumnConstraints col2 = new ColumnConstraints(10);
        ColumnConstraints col3 = new ColumnConstraints();
        col3.setFillWidth(true);
        bottomGridPane.getColumnConstraints().addAll(col1, col2, col3);

        RowConstraints row1 = new RowConstraints(10);
        RowConstraints row2 = new RowConstraints(20);
        RowConstraints row3 = new RowConstraints();
        row3.setFillHeight(true);
        row3.setVgrow(Priority.ALWAYS);
        bottomGridPane.getRowConstraints().addAll(row1, row2, row3);
    }

    private void createHtmlFileLabel() {
        htmlFileLabel = new Text("HTML-Datei:");
        bottomGridPane.add(htmlFileLabel, 0, 1);
    }

    private void createHtmlFileWebView() {
        webView = new WebView();
        webEngine = webView.getEngine();
        bottomGridPane.add(webView, 2, 1, 1, 2);
    }

    @Override
    public void run() {

    }

    /**
     * 
     * Sendet eine HTTP GET-Anfrage an der angegebenen URL.
     *
     * @param url URL, an die die Anfrage gesendet wird
     * @param responseFile Datei mit dem HTTP-Ergebnis
     * @throws IOException
     * @throws Exception
     *
    private void sendHttpGetRequest(String url, File responseFile) throws IOException, Exception {
        CloseableHttpClient httpClient = HttpClients.createDefault();
        HttpGet httpGet = new HttpGet(url);
        RequestConfig.Builder builder = RequestConfig.custom();
        builder.setCookieSpec(CookieSpecs.DEFAULT);
        builder.setExpectContinueEnabled(true);
        builder.setStaleConnectionCheckEnabled(true);
        builder.setTargetPreferredAuthSchemes(Arrays.asList(AuthSchemes.NTLM, AuthSchemes.DIGEST));
        builder.setProxyPreferredAuthSchemes(Arrays.asList(AuthSchemes.BASIC));
        builder.setSocketTimeout(10000);
        builder.setConnectTimeout(10000);
        RequestConfig defRequestConfig = builder.build();
        httpGet.setConfig(defRequestConfig);
        httpGet.addHeader("accept", "application.xml");
        HttpResponse response = httpClient.execute(httpGet);
        HttpEntity entity = response.getEntity();
        if (entity != null) {
            InputStream inputStream = entity.getContent();
            FileUtils.copyInputStreamToFile(inputStream, responseFile);
        }
    }    
    */
   
    /**
     * Erzeugt den EventHandler für das Schließen des Movie Parsers.
     *
     * @return EventHandler für das Schließen des Movie Parsers
     */
    protected EventHandler<WindowEvent> createSystemButtonEventHandler() {
        return new EventHandler<WindowEvent>() {
            @Override
            public void handle(WindowEvent event) {
                try {
                    Thread.sleep(200);
                } catch (InterruptedException ex) {
                }

                System.exit(0);
            }
        };
    }

}
